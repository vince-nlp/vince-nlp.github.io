#begin document Toy
0	-
1	(1@NR)
2	(1@NR)
3	(1@NN)
4	(1@PN)
5	(1@PN)
6	(1@NN)
7	(1@PN)
8	(1@NR)
9	(1@NR)
10	(1@PN)
11	(1@PN)
12	(1@PN)
#end document
