#begin document Toy
0	-
1	(1@NR)
2	(2@NR)
3	(3@NN)
4	(4@PN)
5	(4@PN)
6	-
7	-
8	-
9	-
10	-
11	-
12	-
#end document
