More information about the rules file:

a) Each rule is accompanied with its coverage information that shows the total instances 
   correctly classified out of the total instances classified. 

b) At the top of the rules file is a legend providing descriptions of functions used within various rules. 
   The rules design can be broadly classified into two types: 1) pure rules - using information from only 
   one linguistic source (either Webster, or WordNet, or PropBank-style frames, etc.), and 2) mixture rules -
   using information from more than one linguistic source. 
   
c) Rules are grouped in the order by which the linguisitic resources are listed within the file. Within a 
   linguistic resource section there may be both pure and mixture rules. If there are mixture rules then 
   those rules use linguistic information only from the linguistic type sections preceding it. The temporal 
   relation type of a rule is indicated by the return statement accompanying it. In addition to linguistic 
   sources, the rules also make use of additional attributes of the paired entities which are obtained from
   corpus annotations. For more information about the corpus, please see the TimeBank Corpus Annotation 
   Guidelines (http://www.timeml.org/site/timebank/documentation-1.2.html).