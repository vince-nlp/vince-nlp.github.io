More information about files in the download

1) Each of the four specialized classifiers have a set of pruning heuristics 
   (referred to in Section 6, footnote11 in "Temporal Relation Identification 
   and Classification in Clinical Notes") and classification rules 
   (referred to in Section 1, footnote2 in the same paper) associated with them. 
  
2) The pruning heuristics reduce the total possible entity pair group to a 
   smaller size, thus avoiding classifier bias in training, and reducing the 
   chances of misclassifications during testing. The file "pruning_heuristics.txt"
   contains the entire set of heuristics employed in our four classifiers.
   
3) On the otherhand, we have rules defined for only three of the four classifiers.
   They are the intra-sentence event-event classifier (rules file is "intra-sent-ee-rules.txt"), 
   intra-sentence event-time classifier (rules file is "intra-sent-et-rules.txt"), and 
   the inter-sentence event-event classifier (rules file is "inter-sent-ee-rules.txt").
   
4) Rules classify an entity pair to a class if the entity pair satisfies the conditions 
   in a rule. In the paper, we discuss having negative and positive rules. Within the 
   rules file, the negative rules can be identified as the ones that return class NO-REL 
   meaning the entity pair is classified as having no relation. The rules with return 
   types other than NO-REL are positive rules.
   
5) Each rule is accompanied with its coverage information that shows the total instances 
   correctly classified out of the total instances classified. At the top of the
   rules file is a legend providing descriptions of functions used within various rules. 
   The rules' design can be broadly classified into two types: 1) pure rules - using 
   information from only one linguistic source (either Webster, or WordNet, or 
   PropBank-style frames, etc.), and 2) mixture rules - using information from more than 
   one linguistic source. Rules are grouped in the order by which the linguisitic resources 
   are listed within the file. Within a linguistic resource section there may be both pure 
   and mixture rules; if there are mixture rules then those rules use linguistic information 
   only from the linguistic type sections preceding it. The temporal relation type of a 
   rule is indicated by the return statement accompanying it. In addition to linguistic 
   sources, the rules also make use of additional attributes of the entity pairs involved 
   which were taken from corpus annotations. For a more details about the corpus annotations, 
   please see the included annotation guidelines pdf.