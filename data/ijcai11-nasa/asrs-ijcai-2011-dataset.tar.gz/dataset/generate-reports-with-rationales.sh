#!/bin/bash -x
if [ $# -ne 2 ]; then
	echo "PARAMETERS: <labeled reports> <lexicon file>"
	exit -1
fi
REPORTS=$1
LEXICON=$2
while read REPORT_LINE; do
	REPORT_NUM=`echo $REPORT_LINE | cut -d, -f1`
	echo "Report#$REPORT_NUM"
	REPORT_TEXT=`echo $REPORT_LINE | cut -d, -f2`
	echo "$REPORT_TEXT"
	REPORT_ANNOTATIONS=`echo $REPORT_LINE | cut -d, -f3`
	echo "Annotations:$REPORT_ANNOTATIONS"
	echo "Annotation rationales:"
	while read LEX_LINE; do
		CAT_NAME=`echo $LEX_LINE | cut -d: -f1`
		echo $LEX_LINE | cut -d: -f2 | sed -e 's/,/\n/g' | while read KEYWORD; do
			MATCH=`echo $REPORT_TEXT | grep -i "\b$KEYWORD\b"`
			if [ "$MATCH" != "" ]; then
				echo "$CAT_NAME:$KEYWORD"
			fi
		done
	done < $LEXICON
	echo ""
done < $REPORTS
